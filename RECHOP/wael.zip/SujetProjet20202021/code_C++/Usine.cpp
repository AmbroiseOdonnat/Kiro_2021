#include "Usine.h"

Usine::Usine()
{
	id = -1;
	vertexId = -1;
}