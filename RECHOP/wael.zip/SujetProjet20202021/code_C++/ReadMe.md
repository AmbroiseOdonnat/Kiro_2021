## Comment compiler

Le projet est codé en C++, et peut être compilé avec CMake. Voir https://cmake.org/runningcmake/ pour un tutoriel. Par exemple, linux, il peut être compilé avec les commandes suivantes.

```
mkdir Debug
cd Debug
cmake -DCMAKE_BUILD_TYPE=Debug ..
make
```

## Comment utiliser

La commande ci-dessus produit un executable appelé dispatch. Lancer cet executable en ligne de commande et suivre les instructions.