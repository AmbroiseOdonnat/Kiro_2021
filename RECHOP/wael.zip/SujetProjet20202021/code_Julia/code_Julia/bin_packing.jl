#On implémente le first fit


# Fonction qui prend en entrée une liste de poids a1,..., a_n et une taille
# maximale W et qui fait le first fit


function first_fit(a::Vector{Int}, W::Int)::Vector{Int}
    n = length(a)
    f=Vector{Int}(undef,n)
    for i=1:n
        f[i] = 1
    end

    
