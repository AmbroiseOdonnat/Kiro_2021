include("import_all.jl")

instance_zone = lire_instance("instance/europe.csv")

sol_flows = open("solution/bons_flows.txt") do file
    readlines(file)
end

routes_flows = [lire_route(sol_flows[1+r]) for r=1:length(sol_flows)-1]

instance_flow = lire_solution(instance_zone,"solution/bons_flows.txt")

instance_europe = lire_instance("instance/europe.csv")

# Idée pour améliorer es routes

cost_verbose(instance_europe)

instance_flow.routes=routes_flows

cost_verbose(instance_flow)

##
E = instance_europe.E
U=instance_europe.U
F=instance_europe.F
J= instance_europe.J
R = length(routes_flows)
#Chaque jour, on regroupe les routes u -> f ensemble

emballages_zone = instance_europe.emballages

routes_juf = Array{Vector{Route}}(undef, J, U, F)

for j=1:J, u=1:U, f=1:F
    routes_juf[j,u,f]=[]
end

for r in 1:R
    route = routes_flows[r]
    push!(routes_juf[route.j, route.u, route.stops[1].f], route)
end

# Maintenant pour chaque jour on connaît l'ensemble des routes allant de u à f ce jour là
# Regroupons ces routes pour préparer le ibn_packing


for j=1:J, u=1:U, f=1:F
    routes = routes_juf[j,u,f]
    a = Int[]
    for route in routes
        e = indmax(route.stops[1].Q)
        ℓ= emballages_zone[e].l
        x = route.x
        for pile in 1:x
            push!(a,ℓ)
        end
    end
    sort!(a,rev=true)   #for first fit decreasing
